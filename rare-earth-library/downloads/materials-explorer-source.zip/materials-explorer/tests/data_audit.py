"""Independently verify the shipped browser data against CSV and embedded CIFs."""
import csv
import hashlib
import json
import math
import warnings
from collections import Counter
from pathlib import Path

from pymatgen.core import Composition, Structure

root = Path(__file__).resolve().parents[1]
text = (root / 'assets/dataset.js').read_text(encoding='utf-8')
data = json.loads(text[len('window.MATERIALS_DATA = '):].strip().rstrip(';'))
records = data['records']
structures = data['structures']
assert len({r['id'] for r in records}) == len(records)
assert len(records) == data['meta']['parents'] + data['meta']['hydrides']
assert sum(bool(r['structure']) for r in records) == data['meta']['availableRecords']
assert dict(Counter(e for r in records for e in r['elements'])) == data['counts']
for key, s in structures.items():
    assert hashlib.sha256(s['cif'].encode()).hexdigest()[:20] == key
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        parsed = Structure.from_str(s['cif'], fmt='cif')
    assert len(parsed) == s['sites']
    assert math.isclose(parsed.volume, s['volume'], rel_tol=1e-9)
    assert s['density'] > 0
    assert all(0 < a['occupancy'] <= 1 for a in s['atoms'])
    expanded = [(site, element.symbol, occupancy) for site in parsed for element, occupancy in site.species.items()]
    assert len(expanded) == len(s['atoms'])
    for atom, (site, symbol, occupancy) in zip(s['atoms'], expanded):
        assert atom['elem'] == symbol and math.isclose(atom['occupancy'], occupancy)
        assert all(math.isclose(atom[axis], float(site.coords[i]), abs_tol=1e-9) for i, axis in enumerate('xyz'))
for r in records:
    assert sorted(e.symbol for e in Composition(r['formula']).elements) == r['elements']
    if r['structure']:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            comp = Structure.from_str(structures[r['structure']]['cif'], fmt='cif').composition
        assert comp.reduced_composition == Composition(r['formula']).reduced_composition
source = root.parent / '基础数据/rare_earth_alloy_hydride_pairs.csv'
if source.is_file():
    with source.open(encoding='utf-8-sig', newline='') as f:
        csv_rows = {row['pair_id']: row for row in csv.DictReader(f)}
    for r in records:
        row = csv_rows[r['pairId']]
        kind = r['kind']
        assert row[kind + '_formula'] == r['formula']
        assert math.isclose(float(row[kind + '_formation_energy_eV_per_atom']), r['formationEnergy'])
        if kind == 'hydride':
            assert math.isclose(float(row['hydrogenation_energy_eV_per_H']), r['hydrogenationEnergy'])
            assert math.isclose(float(row['hydrogenation_energy_kJ_per_mol_H2']), r['hydrogenationKJ'])
report = {'records': len(records), 'validatedCifs': len(structures), 'checked': ['unique identities', 'periodic frequencies', 'CIF hash', 'all Cartesian coordinates and occupancy', 'CIF composition', 'volume/density', 'CSV formula and energy fidelity']}
(root / 'verification/data-audit.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
