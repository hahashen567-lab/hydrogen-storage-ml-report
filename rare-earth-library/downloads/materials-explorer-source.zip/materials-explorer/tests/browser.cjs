/* Real Edge acceptance tests. Run from any directory: node /path/to/tests/browser.cjs */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const vm = require('node:vm');
const {pathToFileURL} = require('node:url');
const root = path.resolve(__dirname,'..');
let playwright;
try {playwright=require('playwright');} catch {playwright=require(path.resolve(root,'../.qa-tools/node_modules/playwright'));}
const out=path.join(root,'verification'); fs.mkdirSync(out,{recursive:true});
const sandbox={window:{}};vm.runInNewContext(fs.readFileSync(path.join(root,'assets/dataset.js'),'utf8'),sandbox);
const dataset=sandbox.window.MATERIALS_DATA;
const passed=[];
const check=(name,condition)=>{assert.ok(condition,name);passed.push(name);console.log('PASS',name);};
const server=http.createServer((req,res)=>{
  const file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));
  if(!file.startsWith(root+path.sep) && file!==root){res.writeHead(403);res.end();return;}
  let target=file===root?path.join(root,'index.html'):file;
  if(!fs.existsSync(target)||!fs.statSync(target).isFile()){res.writeHead(404);res.end();return;}
  const type={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'};
  res.writeHead(200,{'Content-Type':type[path.extname(target)]||'application/octet-stream'});fs.createReadStream(target).pipe(res);
});
(async()=>{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const url=`http://127.0.0.1:${server.address().port}`;
  const browser=await playwright.chromium.launch({channel:'msedge',headless:true,args:['--use-angle=swiftshader','--enable-unsafe-swiftshader']});
  try {
    const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true});
    const page=await context.newPage();
    const sceneReady=async()=>{
      await page.waitForFunction(()=>['ready','empty','error'].includes(document.getElementById('crystal-viewer').dataset.renderStatus));
      await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
    };
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    const external=[];page.on('request',req=>{if(!req.url().startsWith(url)&&!req.url().startsWith('blob:')&&!req.url().startsWith('data:')&&!req.url().startsWith('file:'))external.push(req.url());});
    await page.goto(url+'/index.html');await page.waitForFunction(()=>!!window.MaterialsExplorer);await sceneReady();
    check('1841 independent records loaded',await page.locator('#result-count').textContent()==='1,841 条');
    check('118 periodic element buttons',await page.locator('[data-element]').count()===118);
    check('WebGL viewer renders available first CIF',await page.locator('#viewer-message').isHidden() && await page.locator('#crystal-viewer canvas').count()>0);
    check('Initial atom count matches parsed CIF',await page.evaluate(()=>{
      const r=window.MaterialsExplorer.getSelection();return document.getElementById('atom-count').textContent.startsWith(window.MATERIALS_DATA.structures[r.structure].atoms.length+' 个');
    }));
    check('Three background grid planes and angstrom axes are enabled',await page.evaluate(()=>{
      const scene=document.getElementById('crystal-viewer').layout.scene;
      return ['x','y','z'].every(axis=>scene[axis+'axis'].showgrid&&scene[axis+'axis'].showbackground&&scene[axis+'axis'].title.text.includes('Å'));
    }));
    check('Atoms are lit smooth 3D spheres in perspective',await page.evaluate(()=>{
      const p=document.getElementById('crystal-viewer');
      return p.layout.scene.camera.projection.type==='perspective'&&p.data.filter(t=>t.type==='mesh3d').every(t=>t.i.length>0&&!t.flatshading&&t.lighting.specular>0);
    }));
    await page.screenshot({path:path.join(out,'desktop.png'),fullPage:true});
    const firstHydride=dataset.records.find(r=>r.kind==='hydride');
    await page.locator(`[data-record="${firstHydride.id}"] .formula-button`).click();await sceneReady();
    check('Clicking an independent row updates structure and energy details',await page.evaluate(()=>MaterialsExplorer.getSelection().id)===firstHydride.id && (await page.locator('#detail-properties').textContent()).includes('氢化能'));
    const expectedLa=dataset.records.filter(r=>r.elements.includes('La')).length;
    await page.locator('[data-element="La"]').click();await sceneReady();
    check('Click La adds chip and filters',await page.locator('[data-remove="La"]').count()===1 && await page.evaluate(()=>MaterialsExplorer.getResults().length)===expectedLa);
    await page.locator('[data-element="Ni"]').click();await sceneReady();
    const beforeH=await page.evaluate(()=>MaterialsExplorer.getResults());
    check('La Ni includes mothers, hydrides and additional elements',beforeH.some(r=>r.kind==='parent')&&beforeH.some(r=>r.kind==='hydride')&&beforeH.some(r=>r.elements.length>3));
    await page.locator('[data-element="H"]').click();await sceneReady();
    const afterH=await page.evaluate(()=>MaterialsExplorer.getResults());
    check('Adding H retains only hydrides including extra elements',afterH.length>0&&afterH.every(r=>r.elements.includes('H'))&&afterH.some(r=>r.elements.length>3));
    check('H filter equals independent expected dataset',afterH.length===dataset.records.filter(r=>['La','Ni','H'].every(e=>r.elements.includes(e))).length);
    await page.locator('[name=match][value=exact]').check();await sceneReady();
    const exact=await page.evaluate(()=>MaterialsExplorer.getResults());
    check('Exact La Ni H returns no records because this dataset has none',exact.length===dataset.records.filter(r=>r.elements.length===3&&['La','Ni','H'].every(e=>r.elements.includes(e))).length&&await page.locator('#empty-state').isVisible());
    await page.locator('[data-element="Ge"]').click();await sceneReady();
    const exactGe=await page.evaluate(()=>MaterialsExplorer.getResults());
    check('Exact La Ni Ge H retains matching quaternary hydrides',exactGe.length===2&&exactGe.every(r=>r.elements.length===4&&['La','Ni','Ge','H'].every(e=>r.elements.includes(e))));
    await page.locator('[data-element="Ge"]').click();await sceneReady();
    await page.locator('#periodic-toggle').click();
    check('Periodic table collapses without losing filter',await page.locator('#periodic-panel').isHidden()&&await page.locator('[data-remove]').count()===3);
    await page.locator('#periodic-toggle').click();
    check('Periodic table expands again',await page.locator('#periodic-panel').isVisible());
    await page.locator('#clear').click();await sceneReady();await page.locator('[name=match][value=contains]').check();await sceneReady();
    await page.locator('#element-input').fill('La、Ni、H');await page.locator('#element-input').press('Enter');await sceneReady();
    check('Typed Chinese separators yield same H search',await page.evaluate(()=>MaterialsExplorer.getResults().length)===afterH.length);
    await page.locator('#element-input').fill('<script>alert(1)</script>');await page.locator('#element-input').press('Enter');
    check('Invalid input produces visible error and keeps results',await page.locator('#search-error').isVisible()&&await page.evaluate(()=>MaterialsExplorer.getResults().length)===afterH.length);
    await page.locator('#clear').click();await page.locator('#element-input').fill('He');await page.locator('#element-input').press('Enter');
    check('Valid element with no records shows empty state',await page.locator('#empty-state').isVisible()&&await page.locator('#download-cif').isDisabled());
    await page.locator('#empty-clear').click();await sceneReady();await page.locator('#next-page').click();
    check('Pagination changes page and record range',await page.locator('#page-number').textContent()==='2 / 93' && (await page.locator('#page-summary').textContent()).includes('21–40'));
    const missing=dataset.records.find(r=>!r.structure);
    await page.evaluate(id=>MaterialsExplorer.select(id),missing.id);
    check('Missing CIF visible while energy details remain',await page.locator('#viewer-message').isVisible()&&await page.locator('#download-cif').isDisabled()&&(await page.locator('#detail-properties').textContent()).includes('eV/atom'));
    const available=dataset.records.find(r=>r.kind==='hydride'&&r.elements.includes('La')&&r.elements.includes('Ni')&&r.structure);
    await page.evaluate(id=>MaterialsExplorer.select(id),available.id);await sceneReady();
    const atoms=dataset.structures[available.structure].atoms.length;
    await page.locator('[data-repeat="2"]').click();await sceneReady();
    check('Supercell displays exactly eight times the atoms',(await page.locator('#atom-count').textContent()).startsWith(atoms*8+' 个'));
    check('Supercell sphere meshes contain eight times the actual atom centers',await page.evaluate(()=>document.getElementById('crystal-viewer').data.filter(t=>t.type==='mesh3d').reduce((n,t)=>n+t.meta.atomCount,0))===atoms*8);
    await page.locator('#show-cell').uncheck();await sceneReady();check('Cell frame toggle works',await page.evaluate(()=>!document.getElementById('crystal-viewer').data.some(t=>t.mode==='lines'))&&await page.locator('#viewer-message').isHidden());
    await page.locator('#show-cell').check();await sceneReady();await page.locator('[data-repeat="1"]').click();await sceneReady();
    await page.locator('#show-grid').uncheck();await sceneReady();
    check('Grid switch removes planes and ticks without changing atoms',await page.evaluate(()=>{
      const p=document.getElementById('crystal-viewer');return !p.layout.scene.xaxis.visible&&p.data.filter(t=>t.type==='mesh3d').reduce((n,t)=>n+t.meta.atomCount,0)>0;
    }));
    await page.locator('#show-grid').check();await sceneReady();
    const imageBefore=await page.locator('#crystal-viewer').screenshot();
    const box=await page.locator('#crystal-viewer').boundingBox();
    await page.mouse.move(box.x+box.width*.4,box.y+box.height*.5);await page.mouse.down();await page.mouse.move(box.x+box.width*.7,box.y+box.height*.7,{steps:12});await page.mouse.up();
    const imageAfter=await page.locator('#crystal-viewer').screenshot();
    check('Dragging rotates actual rendered structure',!imageBefore.equals(imageAfter));
    await page.mouse.wheel(0,-160);
    const imageZoomed=await page.locator('#crystal-viewer').screenshot();
    check('Mouse wheel zoom changes the rendered structure',!imageAfter.equals(imageZoomed));
    const cameraBefore=await page.evaluate(()=>JSON.stringify(document.getElementById('crystal-viewer').layout.scene.camera));
    await page.locator('#show-grid').uncheck();await sceneReady();
    check('Grid toggle preserves the rotated and zoomed camera',await page.evaluate(()=>JSON.stringify(document.getElementById('crystal-viewer').layout.scene.camera))===cameraBefore);
    await page.locator('#show-grid').check();await sceneReady();
    await page.locator('#reset-view').click();await sceneReady();
    await page.locator('.structure-layout').screenshot({path:path.join(out,'crystal-grid.png')});
    await page.evaluate(()=>window.getSelection()?.removeAllRanges());
    const downloadEvent=page.waitForEvent('download');await page.locator('#download-cif').click();const download=await downloadEvent;
    const downloaded=await download.path();check('CIF download matches original text',fs.readFileSync(downloaded,'utf8')===dataset.structures[available.structure].cif);
    await page.evaluate(()=>MaterialsExplorer.setFilter(['La','Ni'],'contains'));await sceneReady();
    await page.locator('#periodic-toggle').click();
    await page.screenshot({path:path.join(out,'search-and-structure.png'),fullPage:true});
    await page.setViewportSize({width:390,height:844});
    await page.waitForFunction(()=>{const p=document.getElementById('crystal-viewer');return p._fullLayout.width===p.clientWidth&&p._fullLayout.height===p.clientHeight;});
    check('Mobile WebGL canvas resizes to the visible container',await page.evaluate(()=>{const p=document.getElementById('crystal-viewer');return p._fullLayout.width<390&&p._fullLayout.height===365;}));
    await page.screenshot({path:path.join(out,'mobile.png'),fullPage:true});
    check('Mobile document has no horizontal overflow',await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth));
    await page.evaluate(()=>MaterialsExplorer.setFilter([]));await sceneReady();
    const availableRecords=dataset.records.filter(r=>r.structure);
    const dense=availableRecords.reduce((a,b)=>dataset.structures[a.structure].atoms.length>dataset.structures[b.structure].atoms.length?a:b);
    const skew=availableRecords.find(r=>dataset.structures[r.structure].angles.some(a=>a>140));
    for(const r of [dense,skew]){
      await page.evaluate(id=>MaterialsExplorer.select(id),r.id);await sceneReady();
      const actual=await page.evaluate(()=>document.getElementById('crystal-viewer').data.filter(t=>t.type==='mesh3d').flatMap(t=>Array.from({length:t.meta.atomCount},(_,i)=>{
        const start=i*t.meta.verticesPerAtom,end=start+t.meta.verticesPerAtom;
        return [t.name,...['x','y','z'].map(a=>Math.round(t[a].slice(start,end).reduce((n,v)=>n+v,0)/t.meta.verticesPerAtom*1e7)/1e7)];
      })));
      const expected=dataset.structures[r.structure].atoms.map(a=>[a.elem,...['x','y','z'].map(axis=>Math.round(a[axis]*1e7)/1e7)]);
      check(`Correct coordinates rendered for ${r===dense?'densest':'skewed'} CIF`,JSON.stringify(actual.sort())===JSON.stringify(expected.sort())&&await page.locator('#viewer-message').isHidden());
      check(`Physical axis proportions preserved for ${r===dense?'densest':'skewed'} CIF`,await page.evaluate(()=>{
        const s=document.getElementById('crystal-viewer').layout.scene;
        const units=['x','y','z'].map(a=>s.aspectratio[a]/(s[a+'axis'].range[1]-s[a+'axis'].range[0]));
        return Math.max(...Object.values(s.aspectratio))<=1.800001&&Math.max(...units)-Math.min(...units)<1e-9;
      }));
    }
    await page.setViewportSize({width:1440,height:1000});
    await page.evaluate(id=>MaterialsExplorer.select(id),dense.id);await sceneReady();
    await page.locator('.structure-layout').screenshot({path:path.join(out,'crystal-grid-dense.png')});
    await page.goto(url+'/embed-example.html');
    const frame=page.frameLocator('#materials-frame');await frame.locator('#result-count').waitFor();
    await page.locator('#filter-example').click();
    await frame.locator('[data-remove="H"]').waitFor();
    check('Host sends filter to iframe',await frame.locator('[data-remove]').count()===3);
    check('Iframe selection event reaches host',(await page.locator('#selection').textContent()).includes('当前选择'));
    const child=page.frames().find(f=>f.url().includes('index.html'));
    check('Untrusted postMessage is ignored',await child.evaluate(()=>{const n=MaterialsExplorer.getResults().length;window.dispatchEvent(new MessageEvent('message',{origin:'https://untrusted.invalid',source:parent,data:{type:'materials-explorer:set-filter',elements:['He']}}));return n===MaterialsExplorer.getResults().length;}));
    await page.setViewportSize({width:1440,height:1000});
    await page.goto(pathToFileURL(path.join(root,'index.html')).href);await page.waitForFunction(()=>!!window.MaterialsExplorer);await sceneReady();
    check('Direct file HTML opens with working 3D',await page.locator('#viewer-message').isHidden()&&await page.locator('#crystal-viewer canvas').count()>0);
    check('No uncaught JavaScript errors',errors.length===0);
    check('HTTP page performs no external network requests',external.length===0);
    fs.writeFileSync(path.join(out,'browser-results.json'),JSON.stringify({browser:'Microsoft Edge (headless, SwiftShader WebGL)',passed:passed.length,checks:passed,errors,externalRequests:external},null,2));
    await context.close();
  } finally {await browser.close();}
})().then(()=>server.close()).catch(error=>{console.error(error);server.close();process.exitCode=1;});
