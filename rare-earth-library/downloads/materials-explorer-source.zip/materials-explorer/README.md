# 稀土合金与氢化物交互展示

## 打开页面

解压整个代码包后，用 Edge、Chrome 或 Firefox 打开 `index.html`。查看和筛选无需 Python、Node、联网或 API key；请保留 `assets`、`vendor` 相对位置。3D 需要浏览器支持 WebGL。

初始数据为 Alexandria：832 个独立母体、1009 个独立氢化物，共 1841 条。1663 个条目有可用 CIF；178 个母体条目缺少 CIF，保留其能量信息并标注缺失。原始 CSV 按配对记录，网页按材料 ID 去重，因此条目数与 CIF 文件数或配对数不同。

## 检索与查看

- 点击周期表元素立即筛选，再次点击取消；也可以在输入框输入 `La Ni H`、`La、Ni、H`、`La-Ni-H` 或 `LaNiH` 后按回车／查询。元素符号区分大小写的组合写法；单个小写符号会自动规范化，不支持计量数字。
- 默认“包含所选元素”：同时包含 La、Ni、H 的材料均保留，包括还含 Mg 的材料。
- “仅含所选元素”：元素集合完全相同，H 也参与比较；未选择任何元素时显示全部。
- 周期表计数为包含该元素的独立条目数，始终针对当前导入数据全集，不随筛选变化；同一条目可计入多个元素。
- 每个结构独立一行，同一母体及其氢化物相邻排列。分页可能将一组分成两页；详情区可直接切换当前筛选范围内的关联条目。
- 点击条目更新下方晶胞。左键拖动旋转，滚轮缩放，Shift + 拖动平移；可以显示 2×2×2 超胞、分别隐藏坐标网格或晶胞框、恢复视角、悬停或点击原子查看元素／占位率和坐标。
- 结构视图区采用三面浅色坐标网格、带 Å 单位的笛卡尔坐标轴、透视视角及蓝灰色真实晶胞框。原子使用光滑三维球面，带方向光照、高光和明暗层次；H 的显示半径较小。坐标网格和球半径为观看辅助，真实晶格和原子中心坐标均保持不变；细长晶胞会整体缩放以适配视区，三个方向的真实长度比例保持一致。
- 下载按钮输出原始 CIF 文本。球半径仅用于显示，不表示离子或共价半径，不自动连化学键。

## 嵌入其他网页

复制整个 `materials-explorer` 目录到目标网站，在需要的位置加入：

```html
<iframe
  title="稀土材料结构库"
  src="./materials-explorer/index.html?embed=1"
  style="width:100%;height:1700px;border:0"
></iframe>
```

`embed=1` 隐藏独立页的标题；高度可按宿主页面调整。不同域名可以嵌入，服务器需允许 iframe；有 sandbox 时需 `allow-scripts allow-downloads`，同源直接 API 还需 `allow-same-origin`。

预设检索条件：`index.html?embed=1&elements=La,Ni,H&mode=contains`；精确模式为 `mode=exact`。

打开 `embed-example.html` 可看完整接入示例。如果要跨 iframe 传递筛选和选中事件，用 HTTP 提供页面，并在 iframe URL 中设置 `parentOrigin` 为宿主页面的 origin（带协议和端口，不带路径）：

```js
const origin = window.location.origin;
frame.src = './materials-explorer/index.html?embed=1&parentOrigin=' + encodeURIComponent(origin);
frame.contentWindow.postMessage({
  type: 'materials-explorer:set-filter',
  elements: ['La', 'Ni', 'H'], mode: 'contains'
}, new URL(frame.src, location.href).origin);

window.addEventListener('message', event => {
  if (event.source !== frame.contentWindow) return;
  if (event.origin !== new URL(frame.src, location.href).origin) return;
  if (event.data.type === 'materials-explorer:select') console.log(event.data.formula);
});
```

请在 iframe 的 `load` 或 `materials-explorer:ready` 之后发筛选消息。模块校验消息来源为父窗口且 origin 与 `parentOrigin` 一致；未设置时不接收父页消息，也不向父页广播。事件包括 `ready`、`filter`、`select`、`error`。

同一页面或同源 iframe 也可以直接调用：

```js
MaterialsExplorer.setFilter(['La', 'Ni'], 'contains'); // 返回匹配条目数
MaterialsExplorer.getResults(); // 当前匹配条目数组
MaterialsExplorer.getSelection(); // 当前选择或 null
MaterialsExplorer.select(id); // 选择匹配范围内的 ID，并切换所在页
```

本地 HTTP 预览（命令需在此文件所在目录执行）：

```console
python -m http.server 8765 --bind 127.0.0.1
```

然后打开 `http://127.0.0.1:8765/embed-example.html`。此命令仅用作本地预览，正式网站请使用自己的静态托管服务。

## 替换数据和修改源代码

目录职责：`index.html` 为结构；`assets/style.css` 为样式；`assets/app.js` 为交互与公开 API；`vendor` 为本地第三方查看器；`scripts/build_data.py` 为数据整理；`data-report.json` 为核查明细。

页面打开不需要安装依赖。只有重新整理数据时才需要 Python、pymatgen 和 spglib。此包使用环境为 Python 3.8、pymatgen 2023.7.17；也可在独立 Python 环境安装兼容版本。脚本不调用外部材料数据库。

基础数据目录需包含 `rare_earth_alloy_hydride_pairs.csv`、`rare_earth_alloys/` 和 `rare_earth_hydrides/`，CSV 字段沿用当前项目格式。在此目录执行：

```console
python scripts/build_data.py --source "你的基础数据目录" --database Alexandria
```

也支持 `--database JARVIS`、`--database "Materials Project"` 或 `--database all`。其他来源不会混入默认展示。不同数据库的能量参考和校正可能不同，不能直接比较数值。

脚本核对 CIF 组成、展开对称位置、导出真实笛卡尔坐标和晶格；相同材料 ID 去重。CIF 引用缺失时仅尝试匹配同来源、同种类、同材料 ID 的现有文件，否则明确缺失，不猜测替代结构。解析错误写入报告并以非零状态退出。脚本会重写生成的 `assets/dataset.js`、`assets/elements.js` 和 `data-report.json`，不修改原始数据。

空间群由 pymatgen/spglib 以 `symprec=0.01 Å`、角度容差 `5°` 识别，可能随容差变化；不是简单照抄导出 CIF 中的 P1。晶格参数与结构视图保持原始晶胞，不自动转标准胞。部分占位按同一坐标显示原子球，占位率可点击查看。氢化能是 0 K DFT 反应能，未含零点能与温度修正。母体与氢化物按去氢后比例配对，不代表同一骨架。

## 复现验收

页面运行不需要 npm。修改交互代码后，可在安装了 Microsoft Edge 的机器中运行浏览器验收：

```console
npm install --ignore-scripts
npm test
```

测试自动启动本地服务、启动无头 Edge、验证检索／三维／下载／嵌入和本地文件打开，退出时关闭服务和浏览器。截图与结果写入 `verification/`。安装了 Python/pymatgen 后还可运行 `python tests/data_audit.py`，逐项核对导出数据、原始 CIF 坐标和组成；原始 CSV 在默认位置存在时一并核对能量。

## 第三方与许可

- 查看器：[plotly/plotly.js](https://github.com/plotly/plotly.js/tree/v3.1.1)，固定 npm 发行版 **3.1.1**（`plotly.js-dist-min` 的 `plotly.min.js`），**MIT**。调用 `Plotly.react`、`mesh3d` 光照、`scatter3d` 线条、三维坐标场景和 `relayout` 公开 API，无上游源码改写；本项目配色、球面网格、真实晶胞线框、超胞和查看控件由应用层实现。完整版权见 `vendor/Plotly-LICENSE.txt` 及 bundle 头部通知；版本、来源和校验值见 `vendor/provenance.json`。
- CIF 解析与对称性：[materialsproject/pymatgen](https://github.com/materialsproject/pymatgen)（MIT）、[spglib/spglib](https://github.com/spglib/spglib)（BSD-3-Clause），仅数据生成时调用已有环境，不打包其源代码。
- 验收使用 [microsoft/playwright](https://github.com/microsoft/playwright)（Apache-2.0）及本机 Edge，测试工具不属于浏览器运行依赖。

生成页面的数据仍遵循原始材料数据库及其数据集的使用条件；前端代码包不改变原数据的许可。
