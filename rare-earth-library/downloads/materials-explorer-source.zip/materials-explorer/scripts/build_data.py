"""Build an offline browser dataset from the original CSV and CIFs (no API keys)."""
import argparse
import csv
import hashlib
import json
import math
import warnings
from collections import Counter
from pathlib import Path

from pymatgen.core import Composition, Element, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

ROOT = Path(__file__).resolve().parents[1]


def number(value):
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (ValueError, TypeError):
        return None


def build(source, database):
    with (source / 'rare_earth_alloy_hydride_pairs.csv').open(encoding='utf-8-sig', newline='') as f:
        rows = [r for r in csv.DictReader(f) if database == 'all' or r['database'] == database]
    if not rows:
        raise ValueError('No matching CSV records')
    index = {}
    for r in rows:
        for kind, folder in [('parent', 'rare_earth_alloys'), ('hydride', 'rare_earth_hydrides')]:
            path = source / folder / r[kind + '_cif']
            if path.is_file():
                index[(r['database'], kind, r[kind + '_material_id'])] = path
    structures, records, missing, recovered, parse_errors = {}, {}, [], [], []
    cache = {}

    def load(r, kind):
        folder = 'rare_earth_alloys' if kind == 'parent' else 'rare_earth_hydrides'
        path = source / folder / r[kind + '_cif']
        if not path.is_file():
            fallback = index.get((r['database'], kind, r[kind + '_material_id']))
            if fallback:
                recovered.append({'pair': r['pair_id'], 'kind': kind, 'file': fallback.name})
                path = fallback
            else:
                missing.append({'pair': r['pair_id'], 'kind': kind, 'file': path.name})
                return None
        content = path.read_text(encoding='utf-8-sig')
        key = hashlib.sha256(content.encode()).hexdigest()[:20]
        if key not in cache:
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter('ignore')
                    s = Structure.from_str(content, fmt='cif')
                if s.composition.reduced_composition != Composition(r[kind + '_formula']).reduced_composition:
                    raise ValueError('CIF composition differs from CSV')
                atoms = []
                for site in s:
                    for element, occupancy in site.species.items():
                        xyz = site.coords.tolist()
                        if not all(math.isfinite(x) for x in xyz):
                            raise ValueError('Non-finite coordinates')
                        atoms.append({'elem': element.symbol, 'x': xyz[0], 'y': xyz[1], 'z': xyz[2], 'occupancy': occupancy})
                symmetry = None
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter('ignore')
                        analyzer = SpacegroupAnalyzer(s, symprec=0.01, angle_tolerance=5)
                        symmetry = {'symbol': analyzer.get_space_group_symbol(), 'number': analyzer.get_space_group_number(), 'system': analyzer.get_crystal_system()}
                except Exception:
                    pass  # Display "unidentified"; never relabel an export P1 as a verified symmetry.
                structures[key] = {'atoms': atoms, 'lattice': s.lattice.matrix.tolist(), 'lengths': list(s.lattice.abc), 'angles': list(s.lattice.angles), 'volume': float(s.volume), 'density': float(s.density), 'sites': len(s), 'symmetry': symmetry, 'cif': content, 'filename': path.name}
                cache[key] = key
            except Exception as exc:
                parse_errors.append({'file': path.name, 'error': str(exc)})
                cache[key] = None
        return cache[key]

    for i, r in enumerate(rows):
        parent_id = r['database'] + ':' + r['parent_material_id']
        for kind in ['parent', 'hydride']:
            rid = kind + ':' + r['database'] + ':' + r[kind + '_material_id']
            if rid in records:
                continue
            formula = r[kind + '_formula']
            comp = Composition(formula)
            records[rid] = {'id': rid, 'group': parent_id, 'kind': kind, 'formula': formula, 'parentFormula': r['parent_formula'], 'materialId': r[kind + '_material_id'], 'elements': sorted(e.symbol for e in comp.elements), 'structure': load(r, kind), 'formationEnergy': number(r[kind + '_formation_energy_eV_per_atom']), 'hydrogenationEnergy': number(r['hydrogenation_energy_eV_per_H']) if kind == 'hydride' else None, 'hydrogenationKJ': number(r['hydrogenation_energy_kJ_per_mol_H2']) if kind == 'hydride' else None, 'hOverM': number(r['H_over_M']) if kind == 'hydride' else None, 'hullEnergy': number(r[kind + '_energy_above_hull_eV_per_atom']), 'pairId': r['pair_id']}
        if (i + 1) % 100 == 0:
            print('Parsed {}/{} pairs'.format(i + 1, len(rows)), flush=True)
    result = list(records.values())
    result.sort(key=lambda r: (r['parentFormula'], r['group'], r['kind'] != 'parent', r['hOverM'] or 0, r['formula']))
    counts = Counter(e for r in result for e in r['elements'])
    report = {'database': database, 'pairs': len(rows), 'records': len(result), 'parents': sum(r['kind'] == 'parent' for r in result), 'hydrides': sum(r['kind'] == 'hydride' for r in result), 'availableRecords': sum(r['structure'] is not None for r in result), 'uniqueStructures': len(structures), 'missingReferences': missing, 'recoveredReferences': recovered, 'parseErrors': parse_errors, 'symmetryToleranceAngstrom': 0.01, 'sourceCsvSha256': hashlib.sha256((source / 'rare_earth_alloy_hydride_pairs.csv').read_bytes()).hexdigest()}
    dataset = {'meta': {k: v for k, v in report.items() if k not in ['missingReferences', 'recoveredReferences', 'parseErrors']}, 'counts': counts, 'records': result, 'structures': structures}
    text = json.dumps(dataset, ensure_ascii=False, separators=(',', ':'), allow_nan=False).replace('<', '\\u003c')
    (ROOT / 'assets' / 'dataset.js').write_text('window.MATERIALS_DATA = ' + text + ';\n', encoding='utf-8')
    (ROOT / 'data-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    chinese = '氢 氦 锂 铍 硼 碳 氮 氧 氟 氖 钠 镁 铝 硅 磷 硫 氯 氩 钾 钙 钪 钛 钒 铬 锰 铁 钴 镍 铜 锌 镓 锗 砷 硒 溴 氪 铷 锶 钇 锆 铌 钼 锝 钌 铑 钯 银 镉 铟 锡 锑 碲 碘 氙 铯 钡 镧 铈 镨 钕 钷 钐 铕 钆 铽 镝 钬 铒 铥 镱 镥 铪 钽 钨 铼 锇 铱 铂 金 汞 铊 铅 铋 钋 砹 氡 钫 镭 锕 钍 镤 铀 镎 钚 镅 锔 锫 锎 锿 镄 钔 锘 铹 𬬻 𬭊 𬭳 𬭛 𬭶 鿏 𫟼 𬬭 鿔 鿭 𫓧 镆 𫟷 鿬 鿫'.split()
    elements = []
    for z in range(1, 119):
        e = Element.from_Z(z)
        if 57 <= z <= 71:
            row, col = 9, z - 54
        elif 89 <= z <= 103:
            row, col = 10, z - 86
        else:
            row, col = e.row, e.group
        elements.append({'symbol': e.symbol, 'number': z, 'name': chinese[z - 1], 'row': row, 'col': col, 'rare': z in [21, 39] or 57 <= z <= 71})
    (ROOT / 'assets' / 'elements.js').write_text('window.MATERIAL_ELEMENTS = ' + json.dumps(elements, ensure_ascii=False) + ';\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if not isinstance(v, list)}, ensure_ascii=False, indent=2))
    print('Missing references:', len(missing), 'Recovered:', len(recovered), 'Parse errors:', len(parse_errors))
    if parse_errors:
        raise SystemExit('Some CIFs failed validation. See data-report.json')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT.parent / '基础数据')
    parser.add_argument('--database', default='Alexandria', choices=['Alexandria', 'JARVIS', 'Materials Project', 'all'])
    args = parser.parse_args()
    build(args.source.resolve(), args.database)
